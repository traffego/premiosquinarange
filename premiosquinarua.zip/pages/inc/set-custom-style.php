<?php


$theme = $_settings->info('theme');

if ($theme == '2') {
	echo '    <style>' . "\r\n" . '        :root{--incrivel-bg:#0f121a;--incrivel-border:#d1d1d1;--incrivel-bgColor:#fff;--incrivel-bgLink:#fff;--incrivel-bgLinkHover:var(--incrivel-primaria);--incrivel-rgba:255,255,255;--incrivel-rgbaInvert:#fff;--incrivel-formBg:#fff;--incrivel-formBgHover:#fff;--incrivel-formBgHoverColor:#fff;--incrivel-formBorder:#c9c9c9;--incrivel-formColor:#fff;--incrivel-cardBg:#0f121a;--incrivel-cardColor:#fff;--incrivel-cardLink:#fff;--incrivel-modalBg:#fff;--incrivel-modalBorder:#eee;--incrivel-modalColor:#333;--incrivel-primaria:#000;--incrivel-primariaColor:#cfcfcf;--incrivel-primariaLink:#fff;--incrivel-primariaLinkHover:#fff;--incrivel-primariaDarken:#343a40;--incrivel-primariaDarkenColor:#323232;--incrivel-primariaDarkenLink:#fff;--incrivel-primariaDarkenLinkHover:#fff}' . "\r\n" . '    </style>' . "\r\n";
}
else if ($theme == '3') {
	echo '    <style>' . "\r\n" . '        :root{--incrivel-bg:#727e8c;--incrivel-border:#d1d1d1;--incrivel-bgColor:#fff;--incrivel-bgLink:#fff;--incrivel-bgLinkHover:var(--incrivel-primaria);--incrivel-rgba:255,255,255;--incrivel-rgbaInvert:#fff;--incrivel-formBg:#fff;--incrivel-formBgHover:#d9d9d9;--incrivel-formBgHoverColor:#545454;--incrivel-formBorder:#c9c9c9;--incrivel-formColor:#5a5a5a;--incrivel-cardBg:#212b36;--incrivel-cardColor:#fff;--incrivel-cardLink:#000;--incrivel-modalBg:#fff;--incrivel-modalBorder:#eee;--incrivel-modalColor:#333;--incrivel-primaria:#212b36;--incrivel-primariaColor:#cfcfcf;--incrivel-primariaLink:#fff;--incrivel-primariaLinkHover:#fff;--incrivel-primariaDarken:#435365;--incrivel-primariaDarkenColor:#323232;--incrivel-primariaDarkenLink:#fff;--incrivel-primariaDarkenLinkHover:#fff}' . "\r\n" . '    </style>' . "\r\n";
}
else if ($theme == '4') {
	echo '    <style>' . "\r\n" . '        :root{--incrivel-bg:#36175b;--incrivel-border:#d1d1d1;--incrivel-bgColor:#fff;--incrivel-bgLink:#fff;--incrivel-bgLinkHover:var(--incrivel-primaria);--incrivel-rgba:255,255,255;--incrivel-rgbaInvert:#fff;--incrivel-formBg:#fff;--incrivel-formBgHover:#d9d9d9;--incrivel-formBgHoverColor:#545454;--incrivel-formBorder:#c9c9c9;--incrivel-formColor:#5a5a5a;--incrivel-cardBg:#1f0d35;--incrivel-cardColor:#fff;--incrivel-cardLink:#000;--incrivel-modalBg:#fff;--incrivel-modalBorder:#eee;--incrivel-modalColor:#333;--incrivel-primaria:#1f0d35;--incrivel-primariaColor:#cfcfcf;--incrivel-primariaLink:#fff;--incrivel-primariaLinkHover:#fff;--incrivel-primariaDarken:#250043;--incrivel-primariaDarkenColor:#323232;--incrivel-primariaDarkenLink:#fff;--incrivel-primariaDarkenLinkHover:#fff}' . "\r\n" . '    </style>' . "\r\n";
}
else if ($theme == '5') {
	echo '    <style>' . "\r\n" . '        :root{--incrivel-bg:#0D0E1C;--incrivel-border:#d1d1d1;--incrivel-bgColor:#fff;--incrivel-bgLink:#fff;--incrivel-bgLinkHover:var(--incrivel-primaria);--incrivel-rgba:255,255,255;--incrivel-rgbaInvert:#fff;--incrivel-formBg:#fff;--incrivel-formBgHover:#d9d9d9;--incrivel-formBgHoverColor:#545454;--incrivel-formBorder:#c9c9c9;--incrivel-formColor:#5a5a5a;--incrivel-cardBg:#282C5E;--incrivel-cardColor:#fff;--incrivel-cardLink:#000;--incrivel-modalBg:#fff;--incrivel-modalBorder:#eee;--incrivel-modalColor:#333;--incrivel-primaria:#363E9B;--incrivel-primariaColor:#fff;--incrivel-primariaLink:#fff;--incrivel-primariaLinkHover:#fff;--incrivel-primariaDarken:#080812;--incrivel-primariaDarkenColor:#323232;--incrivel-primariaDarkenLink:#fff;--incrivel-primariaDarkenLinkHover:#fff}' . "\r\n" . '    </style>' . "\r\n";
}

?>